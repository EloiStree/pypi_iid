# pypi_iid
Utility for Index Integer Date format used by my tool in Python.



------------------------

That is my first python package.

So let's check how to build one.

# Create a pip package

Note: 


`pip install --upgrade build`
https://youtu.be/9Ii34WheBOA?t=449

`cd "GIT_PORJECT_ROOT"`


`python -m build`

A whl file is created and usable as pip install

`pip install iid-2025.1.8-py3-none-any.whl`



```
pip uninstall iid -y
python -m build
pip install dist/iid-2025.1.8.1-py3-none-any.whl
python 
```


``` py
import iid
iid.say_hello()

```
import struct
import random
import socket
from . import HelloWorld


def say_hello():
    HelloWorld.say_hello()

def bytes_to_int(bytes:bytes):
    value= struct.unpack('<i', bytes)[0]
    return value

def bytes_to_index_integer(bytes:bytes):
    index, value = struct.unpack('<ii', bytes)
    return index, value

def  bytes_to_index_integer_date(bytes:bytes):
    index, value, date = struct.unpack('<iiQ', bytes)
    return index, value, date

def integer_to_bytes(value:int):
    return struct.pack('<i', value)

def index_integer_to_bytes(index:int, value:int):
    return struct.pack('<ii', index, value)

def index_integer_date_to_bytes(index:int, value:int, date:int):
    return struct.pack('<iiQ', index, value, date)


class SendUdpIID:
    def __init__(self, ivp4, port):
        self.ivp4 = ivp4
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
    def push_bytes(self, bytes:bytes):
        self.sock.sendto(bytes, (self.ivp4, self.port))
        
    def push_text(self, text:str):
        self.push_bytes(text.encode('utf-8'))
        
    def push_integer(self, value:int):
        self.push_bytes(IID.integer_to_bytes(value))
        
    def push_index_integer(self, index:int, value:int):
        self.push_bytes(IID.index_integer_to_bytes(index, value))
        
    def push_index_integer_date(self, index:int, value:int, date:int):
        self.push_bytes(IID.index_integer_date_to_bytes(index, value, date))
        
    def push_random_integer(self, index:int, from_value:int, to_value:int):
        value = random.randint(from_value, to_value)
        self.push_index_integer(index, value)
        
    def push_random_integer_100(self, index:int):
        self.push_random_integer(index, 0, 100)
        
    def push_random_integer_int_max(self, index:int):
        self.push_random_integer(index, -2147483647, 2147483647)

